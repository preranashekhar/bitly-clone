import json
import pymongo
import sys

def lambda_handler(event, context):
    print("event: ", event)
    print("event records: ", event['Records'])
    
    for record in event['Records']:
        print("record: ", record)
        payload = json.loads(record['body'])
        print("payload: ", payload )