import json
import requests

def lambda_handler(event, context):
    # TODO implement
    
    nosql_endpoint = "https://0AD74E0185E886AB0FA1D16A4F4C16BF.gr7.us-west-2.eks.amazonaws.com"
    key_value = {'somekey1': 'somevalue1'}
    r = requests.post(nosql_endpoint, data = key_value)
    print("status code: ", r.statusCode)
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
